import { Product } from '../types';

export const calculateTotalQuantity = (products: Product[]): number => {
  return products.reduce((total, product) => total + product.quantity, 0);
};

export const calculateTotalSoldQuantity = (products: Product[]): number => {
  return products.reduce((total, product) => total + product.soldQuantity, 0);
};

export const calculateTotalSales = (products: Product[]): number => {
  return products.reduce((total, product) => total + product.price * product.quantity, 0);
};

export const calculateTotalSoldSales = (products: Product[]): number => {
  return products.reduce((total, product) => total + product.price * product.soldQuantity, 0);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
  }).format(amount);
};