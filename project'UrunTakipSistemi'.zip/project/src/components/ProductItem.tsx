import React from 'react';
import { Product } from '../types';
import { formatCurrency } from '../utils/calculations';
import { MinusCircle, PlusCircle, Trash2, ShoppingCart } from 'lucide-react';

interface ProductItemProps {
  product: Product;
  onUpdateQuantity: (id: string, newQuantity: number) => void;
  onUpdateSoldQuantity: (id: string, newSoldQuantity: number) => void;
  onRemoveProduct: (id: string) => void;
}

const ProductItem: React.FC<ProductItemProps> = ({
  product,
  onUpdateQuantity,
  onUpdateSoldQuantity,
  onRemoveProduct,
}) => {
  const handleIncrement = () => {
    onUpdateQuantity(product.id, product.quantity + 1);
  };

  const handleDecrement = () => {
    if (product.quantity > 1) {
      onUpdateQuantity(product.id, product.quantity - 1);
    }
  };

  const handleSold = () => {
    if (product.quantity > product.soldQuantity) {
      onUpdateSoldQuantity(product.id, product.soldQuantity + 1);
    }
  };

  const availableQuantity = product.quantity - product.soldQuantity;
  const totalSoldPrice = product.price * product.soldQuantity;

  return (
    <div className="bg-white border border-gray-100 rounded-xl p-4 mb-4 shadow-sm transition-all duration-300 hover:shadow-md">
      <div className="flex flex-col gap-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h3 className="text-lg font-medium text-gray-800">{product.name}</h3>
            <p className="text-gray-500 text-sm">Birim Fiyat: {formatCurrency(product.price)}</p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex items-center">
              <button
                onClick={handleDecrement}
                className="p-1 text-gray-500 hover:text-blue-500 transition-colors focus:outline-none disabled:opacity-30"
                disabled={product.quantity <= 1}
                aria-label="Azalt"
              >
                <MinusCircle size={20} />
              </button>
              
              <span className="mx-3 w-8 text-center font-medium text-gray-700">
                {product.quantity}
              </span>
              
              <button
                onClick={handleIncrement}
                className="p-1 text-gray-500 hover:text-blue-500 transition-colors focus:outline-none"
                aria-label="Arttır"
              >
                <PlusCircle size={20} />
              </button>
            </div>

            <button
              onClick={() => onRemoveProduct(product.id)}
              className="p-1 text-gray-400 hover:text-red-500 transition-colors focus:outline-none ml-auto sm:ml-4"
              aria-label="Sil"
            >
              <Trash2 size={18} />
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-t pt-4">
          <div className="flex items-center gap-2">
            <button
              onClick={handleSold}
              disabled={availableQuantity === 0}
              className="flex items-center gap-2 px-3 py-1.5 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 active:bg-green-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-green-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingCart size={16} />
              <span>Satıldı</span>
            </button>
            <span className="text-sm text-gray-500">
              (Kalan: {availableQuantity} adet)
            </span>
          </div>
          
          <div className="mt-2 sm:mt-0">
            <p className="text-sm text-gray-600">
              Satılan: <span className="font-medium">{product.soldQuantity}</span> adet
            </p>
            <p className="text-sm font-medium text-gray-700">
              Toplam Satış: {formatCurrency(totalSoldPrice)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductItem;