import React from 'react';
import { Product, ProductGroup } from '../types';
import { calculateTotalQuantity, calculateTotalSales, calculateTotalSoldQuantity, calculateTotalSoldSales, formatCurrency } from '../utils/calculations';
import { LineChart, DollarSign, Package, ShoppingCart } from 'lucide-react';

interface SalesSummaryProps {
  products: Product[];
  groups: ProductGroup[];
}

const SalesSummary: React.FC<SalesSummaryProps> = ({ products, groups }) => {
  const totalQuantity = calculateTotalQuantity(products);
  const totalSoldQuantity = calculateTotalSoldQuantity(products);
  const totalSoldSales = calculateTotalSoldSales(products);
  const totalInventoryValue = calculateTotalSales(products);

  // Calculate group summaries
  const groupSummaries = groups.map(group => {
    const groupProducts = products.filter(p => p.groupId === group.id);
    return {
      name: group.name,
      soldQuantity: calculateTotalSoldQuantity(groupProducts),
      totalSales: calculateTotalSoldSales(groupProducts),
    };
  }).filter(summary => summary.soldQuantity > 0);

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-6 shadow-lg">
        <h2 className="text-xl font-medium mb-4">Satış Özeti</h2>
        
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center mb-2">
              <Package size={20} className="mr-2" />
              <h3 className="font-medium">Toplam Stok</h3>
            </div>
            <p className="text-3xl font-bold">{totalQuantity}</p>
            <p className="text-sm text-blue-100 mt-1">Stok Değeri: {formatCurrency(totalInventoryValue)}</p>
          </div>
          
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center mb-2">
              <ShoppingCart size={20} className="mr-2" />
              <h3 className="font-medium">Toplam Satış Adedi</h3>
            </div>
            <p className="text-3xl font-bold">{totalSoldQuantity}</p>
            <p className="text-sm text-blue-100 mt-1">
              {products.length > 0 
                ? `Satış oranı: %${((totalSoldQuantity / totalQuantity) * 100).toFixed(1)}`
                : "Henüz satış yok"}
            </p>
          </div>

          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center mb-2">
              <DollarSign size={20} className="mr-2" />
              <h3 className="font-medium">Toplam Satış Tutarı</h3>
            </div>
            <p className="text-3xl font-bold">{formatCurrency(totalSoldSales)}</p>
            <p className="text-sm text-blue-100 mt-1">
              {totalSoldQuantity > 0 
                ? `Ürün başına ortalama: ${formatCurrency(totalSoldSales / totalSoldQuantity)}`
                : "Henüz satış yok"}
            </p>
          </div>
        </div>
      </div>

      {groupSummaries.length > 0 && (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-medium mb-4 text-gray-800">Grup Bazlı Satışlar</h3>
          <div className="space-y-4">
            {groupSummaries.map((summary, index) => (
              <div key={index} className="border-b border-gray-100 last:border-0 pb-4 last:pb-0">
                <h4 className="font-medium text-gray-700">{summary.name}</h4>
                <div className="flex justify-between mt-2 text-sm">
                  <span className="text-gray-500">Satılan Adet: {summary.soldQuantity}</span>
                  <span className="text-gray-700 font-medium">{formatCurrency(summary.totalSales)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesSummary;