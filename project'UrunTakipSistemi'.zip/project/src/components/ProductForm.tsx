import React, { useState } from 'react';
import { ProductFormData, ProductGroup } from '../types';
import { PlusCircle, FolderPlus } from 'lucide-react';

interface ProductFormProps {
  onAddProduct: (product: ProductFormData) => void;
  groups: ProductGroup[];
  onAddGroup: (name: string) => void;
}

const ProductForm: React.FC<ProductFormProps> = ({ onAddProduct, groups, onAddGroup }) => {
  const [formData, setFormData] = useState<ProductFormData>({
    name: '',
    price: '',
    quantity: '1',
    groupId: null,
  });

  const [newGroupName, setNewGroupName] = useState('');
  const [showGroupInput, setShowGroupInput] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof ProductFormData | 'group', string>>>({});

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ProductFormData | 'group', string>> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Ürün ismi gereklidir';
    }
    
    if (!formData.price) {
      newErrors.price = 'Fiyat gereklidir';
    } else if (isNaN(parseFloat(formData.price)) || parseFloat(formData.price) <= 0) {
      newErrors.price = 'Geçerli bir fiyat giriniz';
    }
    
    if (!formData.quantity) {
      newErrors.quantity = 'Miktar gereklidir';
    } else if (isNaN(parseInt(formData.quantity)) || parseInt(formData.quantity) <= 0) {
      newErrors.quantity = 'Geçerli bir miktar giriniz';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'groupId' ? (value === '' ? null : value) : value,
    }));
    
    if (errors[name as keyof ProductFormData]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onAddProduct(formData);
      setFormData({
        name: '',
        price: '',
        quantity: '1',
        groupId: formData.groupId, // Keep the selected group
      });
    }
  };

  const handleAddGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (newGroupName.trim()) {
      onAddGroup(newGroupName.trim());
      setNewGroupName('');
      setShowGroupInput(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6 transition-all duration-300 hover:shadow-md">
      <h2 className="text-xl font-medium mb-4 text-gray-800">Yeni Ürün Ekle</h2>
      
      <div className="mb-4">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ürün Grubu
          </label>
          <button
            type="button"
            onClick={() => setShowGroupInput(!showGroupInput)}
            className="text-sm text-blue-500 hover:text-blue-600 flex items-center gap-1"
          >
            <FolderPlus size={16} />
            <span>Yeni Grup Ekle</span>
          </button>
        </div>

        {showGroupInput && (
          <form onSubmit={handleAddGroup} className="mb-4 flex gap-2">
            <input
              type="text"
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:outline-none border-gray-300 focus:ring-blue-100 focus:border-blue-400"
              placeholder="Grup adı"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300"
            >
              Ekle
            </button>
          </form>
        )}

        <select
          name="groupId"
          value={formData.groupId || ''}
          onChange={handleChange}
          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:outline-none border-gray-300 focus:ring-blue-100 focus:border-blue-400"
        >
          <option value="">Grup seçiniz (opsiyonel)</option>
          {groups.map((group) => (
            <option key={group.id} value={group.id}>
              {group.name}
            </option>
          ))}
        </select>
      </div>
      
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Ürün Adı
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:outline-none transition-colors ${
              errors.name ? 'border-red-300 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-100 focus:border-blue-400'
            }`}
            placeholder="Ürün adı"
          />
          {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
        </div>
        
        <div className="space-y-2">
          <label htmlFor="price" className="block text-sm font-medium text-gray-700">
            Fiyat (₺)
          </label>
          <input
            type="number"
            id="price"
            name="price"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:outline-none transition-colors ${
              errors.price ? 'border-red-300 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-100 focus:border-blue-400'
            }`}
            placeholder="0.00"
          />
          {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price}</p>}
        </div>
        
        <div className="space-y-2">
          <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">
            Miktar
          </label>
          <input
            type="number"
            id="quantity"
            name="quantity"
            min="1"
            value={formData.quantity}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:outline-none transition-colors ${
              errors.quantity ? 'border-red-300 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-100 focus:border-blue-400'
            }`}
            placeholder="1"
          />
          {errors.quantity && <p className="text-red-500 text-xs mt-1">{errors.quantity}</p>}
        </div>

        <div className="md:col-span-3">
          <button
            type="submit"
            className="mt-5 flex items-center justify-center gap-2 w-full md:w-auto px-5 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 active:bg-blue-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300"
          >
            <PlusCircle size={18} />
            <span>Ürün Ekle</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProductForm;