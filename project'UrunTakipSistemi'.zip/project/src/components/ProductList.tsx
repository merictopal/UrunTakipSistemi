import React, { useState } from 'react';
import { Product, ProductGroup } from '../types';
import ProductItem from './ProductItem';
import { ShoppingBasket, FolderOpen, ChevronDown, ChevronUp, Trash2 } from 'lucide-react';

interface ProductListProps {
  products: Product[];
  groups: ProductGroup[];
  onUpdateQuantity: (id: string, newQuantity: number) => void;
  onUpdateSoldQuantity: (id: string, newSoldQuantity: number) => void;
  onRemoveProduct: (id: string) => void;
  onRemoveGroup: (groupId: string) => void;
}

const ProductList: React.FC<ProductListProps> = ({
  products,
  groups,
  onUpdateQuantity,
  onUpdateSoldQuantity,
  onRemoveProduct,
  onRemoveGroup,
}) => {
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(groups.map(g => g.id)));

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
      }
      return next;
    });
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-xl border border-dashed border-gray-200">
        <div className="flex justify-center mb-4">
          <ShoppingBasket size={48} className="text-gray-300" />
        </div>
        <h3 className="text-lg font-medium text-gray-500">Henüz ürün eklenmedi</h3>
        <p className="text-gray-400 mt-1">Ürün eklemek için yukarıdaki formu kullanın</p>
      </div>
    );
  }

  // Group products
  const groupedProducts: Record<string | 'ungrouped', Product[]> = {
    ungrouped: [],
  };

  products.forEach((product) => {
    if (product.groupId) {
      if (!groupedProducts[product.groupId]) {
        groupedProducts[product.groupId] = [];
      }
      groupedProducts[product.groupId].push(product);
    } else {
      groupedProducts.ungrouped.push(product);
    }
  });

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-medium mb-4 text-gray-800">Ürün Listesi</h2>

      {/* Grouped Products */}
      {groups.map((group) => {
        const groupProducts = groupedProducts[group.id] || [];
        if (groupProducts.length === 0) return null;

        return (
          <div key={group.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div
              className="flex items-center justify-between p-4 bg-gray-50 cursor-pointer"
              onClick={() => toggleGroup(group.id)}
            >
              <div className="flex items-center gap-2">
                <FolderOpen size={20} className="text-blue-500" />
                <h3 className="font-medium text-gray-800">{group.name}</h3>
                <span className="text-sm text-gray-500">({groupProducts.length} ürün)</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`"${group.name}" grubunu silmek istediğinize emin misiniz?`)) {
                      onRemoveGroup(group.id);
                    }
                  }}
                  className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
                {expandedGroups.has(group.id) ? (
                  <ChevronUp size={20} className="text-gray-400" />
                ) : (
                  <ChevronDown size={20} className="text-gray-400" />
                )}
              </div>
            </div>
            
            {expandedGroups.has(group.id) && (
              <div className="p-4">
                {groupProducts.map((product) => (
                  <div key={product.id} className="animate-fadeIn">
                    <ProductItem
                      product={product}
                      onUpdateQuantity={onUpdateQuantity}
                      onUpdateSoldQuantity={onUpdateSoldQuantity}
                      onRemoveProduct={onRemoveProduct}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* Ungrouped Products */}
      {groupedProducts.ungrouped.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-medium text-gray-700">Gruplanmamış Ürünler</h3>
          {groupedProducts.ungrouped.map((product) => (
            <div key={product.id} className="animate-fadeIn">
              <ProductItem
                product={product}
                onUpdateQuantity={onUpdateQuantity}
                onUpdateSoldQuantity={onUpdateSoldQuantity}
                onRemoveProduct={onRemoveProduct}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductList;