import React from 'react';
import { v4 as uuidv4 } from 'uuid';
import ProductForm from './components/ProductForm';
import ProductList from './components/ProductList';
import SalesSummary from './components/SalesSummary';
import { Product, ProductFormData, ProductGroup } from './types';
import useLocalStorage from './hooks/useLocalStorage';
import { ShoppingCart } from 'lucide-react';

function App() {
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [groups, setGroups] = useLocalStorage<ProductGroup[]>('product-groups', []);

  const handleAddProduct = (productData: ProductFormData) => {
    const newProduct: Product = {
      id: uuidv4(),
      name: productData.name,
      price: parseFloat(productData.price),
      quantity: parseInt(productData.quantity),
      soldQuantity: 0,
      groupId: productData.groupId,
    };

    setProducts((prevProducts) => [...prevProducts, newProduct]);
  };

  const handleAddGroup = (groupName: string) => {
    const newGroup: ProductGroup = {
      id: uuidv4(),
      name: groupName,
    };
    setGroups((prevGroups) => [...prevGroups, newGroup]);
  };

  const handleUpdateQuantity = (id: string, newQuantity: number) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.id === id ? { ...product, quantity: newQuantity } : product
      )
    );
  };

  const handleUpdateSoldQuantity = (id: string, newSoldQuantity: number) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.id === id ? { ...product, soldQuantity: newSoldQuantity } : product
      )
    );
  };

  const handleRemoveProduct = (id: string) => {
    setProducts((prevProducts) => prevProducts.filter((product) => product.id !== id));
  };

  const handleRemoveGroup = (groupId: string) => {
    setGroups((prevGroups) => prevGroups.filter((group) => group.id !== groupId));
    // Reset groupId for products in this group
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.groupId === groupId ? { ...product, groupId: null } : product
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <ShoppingCart size={32} className="text-blue-500" />
            <h1 className="text-3xl font-bold text-gray-900">Ürün Takip Sistemi</h1>
          </div>
          <p className="text-gray-600">Ürünlerinizi ekleyin, gruplandırın ve satışları takip edin</p>
        </header>

        <main className="space-y-8">
          <ProductForm onAddProduct={handleAddProduct} groups={groups} onAddGroup={handleAddGroup} />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <ProductList
                products={products}
                groups={groups}
                onUpdateQuantity={handleUpdateQuantity}
                onUpdateSoldQuantity={handleUpdateSoldQuantity}
                onRemoveProduct={handleRemoveProduct}
                onRemoveGroup={handleRemoveGroup}
              />
            </div>
            
            <div className="lg:col-span-1">
              <SalesSummary products={products} groups={groups} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;