export interface Product {
  id: string;
  name: string;
  price: number;
  quantity: number;
  soldQuantity: number;
  groupId: string | null;
}

export interface ProductFormData {
  name: string;
  price: string;
  quantity: string;
  groupId: string | null;
}

export interface ProductGroup {
  id: string;
  name: string;
}